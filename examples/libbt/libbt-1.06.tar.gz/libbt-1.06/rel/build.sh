gcc btcheck.c -o btcheck -I../include -L../lib -lbt -lcurl -lssl -lm -luuid
gcc btget.c -o btget -I../include -L../lib -lbt -lcurl -lssl -lm -luuid
gcc btlist.c -o btlist -I../include -L../lib -lbt -lcurl -lssl -lm -luuid

