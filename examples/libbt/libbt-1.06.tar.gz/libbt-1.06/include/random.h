#ifndef __RANDOM__H
#define __RANDOM__H

void randomid( char *buf, int bytes);
int rnd( int range);
#endif
